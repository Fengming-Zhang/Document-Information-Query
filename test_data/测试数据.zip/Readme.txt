1.test_querys.csv 测试query,包含每个query机器编号
2.test_docs.csv 文档数据集 包含每篇文档的id,title,content等信息
3. submission.csv  最终提交文档，对于submission文件中的每个query，返回最相关的20篇文档号。最终提交形式如submission.csv所示。
4.提交前请确认文件格式正确，query_id正确，doc_id正确；每个query_id对应20个doc_id,不要缺少或增加。
